<a name="1.2.1"></a>
# 1.2.1 (2017-06-09)

### Features

- \[[FA-262](https://globalitprocess.bbva.com/browse/FA-262)\] Catalog ready \([8963d4d1620](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/8963d4d16205c7efbe4fa94c8a0b5c1450f8efe6)\) \([c8946eb962d](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/c8946eb962d5c4225df57c8d5599f656843960d6)\)
- \[[FA-262](https://globalitprocess.bbva.com/browse/FA-262)\] Demo refactor \([c82a3a995f2](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/c82a3a995f2d620ee0e653ccdbbde8400d34b483)\)

<a name="1.2.0"></a>
# 1.2.0 (2017-06-02)

### Features

- [\[FA-215\]](https://globalitprocess.bbva.com/browse/FA-215) Component refactor ([45c5477fd03](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/45c5477fd031a6ab65ba1ee12cbf7aa0024d4776))

<a name="1.1.1"></a>
# 1.1.1 (2017-05-19)

### Features

- [\[FA-215\]](https://globalitprocess.bbva.com/browse/FA-215) Catalog ready ([0db5f2df7f9](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/0db5f2df7f925912a1984a663fe65736bd505fd5))

### Bugfixes

- [\[FA-215\]](https://globalitprocess.bbva.com/browse/FA-215) Minor code issues ([c5cf805bfcc](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/c5cf805bfcc1f6dde5f09ac241f63622da0220a2))

<a name="1.1.0"></a>
# 1.1.0 (2017-05-17)

### Features

- [\[FA-215\]](https://globalitprocess.bbva.com/browse/FA-215) Allow to retrieve last XHR object ([221f35a824d](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/221f35a824d050e5562efc08a9c11b069d83d20d))

<a name="1.0.0"></a>
# 1.0.0 (2017-03-17)

### Features

- [\[GLOMO-1205\]](https://globaldevtools.bbva.com/jira/browse/GLOMO-1205)
- [\[GLOMO-1206\]](https://globaldevtools.bbva.com/jira/browse/GLOMO-1206) Initial release ([c87d8c0ea85](https://globaldevtools.bbva.com/bitbucket/projects/BBVACELLSAPI/repos/cells-generic-dp/commits/c87d8c0ea8561b4612a2f640e4cb284adae971fb))



