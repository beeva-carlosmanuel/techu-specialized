# Coronita Iconset

[![Certificated](https://img.shields.io/badge/certificated-yes-brightgreen.svg)](http://bbva-files.s3.amazonaws.com/cells/bbva-catalog/index.html) 

## Generating iconset

Use [iconset-generator](https://globaldevtools.bbva.com/bitbucket/projects/CTOOL/repos/iconset-generator/browse) to update or build the iconset from `icons.json` file.

Install dependencies:
```bash
$ bower install
``` 

Generate iconset:
```bash
$ generate-iconset
```


