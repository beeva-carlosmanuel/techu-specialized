# Changelog

## v3.1.0

### New icons

- coronita:firstpage
- coronita:lastpage

## v3.0.0

### Breaking changes

#### Removed or renamed icons

- coronita:contract 
- coronita:mobile-26 -> renamed to coronita:mobile
- coronita:mobile-28 (duplicated)
- coronita:mobilepayment -> renamed to coronita:mobilecashdollar
- coronita:notcustomer -> renamed to coronita:noclient

### Changed icons (new design)

- coronita:filter

### New icons

- coronita:alphabeticalorder
- coronita:bakery
- coronita:bizum
- coronita:blog
- coronita:bonusaccount
- coronita:bus
- coronita:butchershop
- coronita:carplus
- coronita:cloud
- coronita:collapse
- coronita:color
- coronita:communicationpublic
- coronita:confectionery
- coronita:couple
- coronita:fastfood
- coronita:frequency
- coronita:frozen
- coronita:icecream
- coronita:identifiedcall
- coronita:illustration
- coronita:jpg
- coronita:keyboard
- coronita:law
- coronita:man
- coronita:medicalkit
- coronita:mobilecasheuro
- coronita:mobilepayment
- coronita:mooncar
- coronita:nurseryroom
- coronita:oneclick
- coronita:pacifier
- coronita:partner
- coronita:pastafactory
- coronita:plusmenu
- coronita:previousapointment
- coronita:receiptok
- coronita:stairs
- coronita:tablet
- coronita:ticketoffice
- coronita:tools
- coronita:turnbox
- coronita:tv
- coronita:videoplayline
- coronita:virtualemail
- coronita:virtualreality
- coronita:watch
- coronita:woman 

