# Changelog

<!-- Document the breaking changes when updating the component as major version.
As well as the necessary changes to upgrade the component (migration guide type).
-->
